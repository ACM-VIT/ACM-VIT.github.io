$(window).scroll(function() {
    $("#main-nav").offset().top > 50 ? $("#main-nav").fadeIn("fast") : $("#main-nav").fadeOut("slow")
}), $(document).ready(function() {
    $("#quote-carousel").carousel({
        pause: !0,
        interval: 5e3
    }), window.width > 769 && ($("#bottomlogo1").addClass("pull-left"), $("#bottomlogo2").addClass("pull-right"))
});

var eveclim4 = 0;
$(document).ready(function() {
    $("#eveliidm4").click(function() {
        eveclim2++, eveclim2 % 2 == 0 ? ($("#eveliidm4").css("background-color", "#ffffff"), $("#eveliidm4 .events3dots").removeClass("fa-arrow-up"), $("#eveliidm4 .events3dots").addClass("fa-arrow-down")) : ($("#eveliidm4").css("background-color", "#eeeeee"), $("#eveliidm4 .events3dots").removeClass("fa-arrow-down"), $("#eveliidm4 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliidm4").hover(function() {
        eveclim2 % 2 == 0 ? ($("#eveliidm4 .events3dots").addClass("fa-arrow-down"), $("#eveliidm4 .events3dots").fadeIn("fast")) : ($("#eveliidm4 .events3dots").addClass("fa-arrow-up"), $("#eveliidm4 .events3dots").fadeIn("fast"))
    }, function() {
        eveclim2 % 2 == 0 ? ($("#eveliidm4 .events3dots").fadeOut("fast"), $("#eveliidm4 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliidm4 .events3dots").fadeOut("fast"), $("#eveliidm4 .events3dots").removeClass("fa-arrow-up"))
    })
});

var eveclim3 = 0;
$(document).ready(function() {
    $("#eveliidm3").click(function() {
        eveclim3++, eveclim3 % 2 == 0 ? ($("#eveliidm3").css("background-color", "#ffffff"), $("#eveliidm3 .events3dots").removeClass("fa-arrow-up"), $("#eveliidm3 .events3dots").addClass("fa-arrow-down")) : ($("#eveliidm3").css("background-color", "#eeeeee"), $("#eveliidm3 .events3dots").removeClass("fa-arrow-down"), $("#eveliidm3 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliidm3").hover(function() {
        eveclim3 % 2 == 0 ? ($("#eveliidm3 .events3dots").addClass("fa-arrow-down"), $("#eveliidm3 .events3dots").fadeIn("fast")) : ($("#eveliidm3 .events3dots").addClass("fa-arrow-up"), $("#eveliidm3 .events3dots").fadeIn("fast"))
    }, function() {
        eveclim3 % 2 == 0 ? ($("#eveliidm3 .events3dots").fadeOut("fast"), $("#eveliidm3 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliidm3 .events3dots").fadeOut("fast"), $("#eveliidm3 .events3dots").removeClass("fa-arrow-up"))
    })
});

var eveclim2 = 0;
$(document).ready(function() {
    $("#eveliidm2").click(function() {
        eveclim2++, eveclim2 % 2 == 0 ? ($("#eveliidm2").css("background-color", "#ffffff"), $("#eveliidm2 .events3dots").removeClass("fa-arrow-up"), $("#eveliidm2 .events3dots").addClass("fa-arrow-down")) : ($("#eveliidm2").css("background-color", "#eeeeee"), $("#eveliidm2 .events3dots").removeClass("fa-arrow-down"), $("#eveliidm2 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliidm2").hover(function() {
        eveclim2 % 2 == 0 ? ($("#eveliidm2 .events3dots").addClass("fa-arrow-down"), $("#eveliidm2 .events3dots").fadeIn("fast")) : ($("#eveliidm2 .events3dots").addClass("fa-arrow-up"), $("#eveliidm2 .events3dots").fadeIn("fast"))
    }, function() {
        eveclim2 % 2 == 0 ? ($("#eveliidm2 .events3dots").fadeOut("fast"), $("#eveliidm2 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliidm2 .events3dots").fadeOut("fast"), $("#eveliidm2 .events3dots").removeClass("fa-arrow-up"))
    })
});

var eveclim1 = 0;
$(document).ready(function() {
    $("#eveliidm1").click(function() {
        eveclim1++, eveclim1 % 2 == 0 ? ($("#eveliidm1").css("background-color", "#ffffff"), $("#eveliidm1 .events3dots").removeClass("fa-arrow-up"), $("#eveliidm1 .events3dots").addClass("fa-arrow-down")) : ($("#eveliidm1").css("background-color", "#eeeeee"), $("#eveliidm1 .events3dots").removeClass("fa-arrow-down"), $("#eveliidm1 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliidm1").hover(function() {
        eveclim1 % 2 == 0 ? ($("#eveliidm1 .events3dots").addClass("fa-arrow-down"), $("#eveliidm1 .events3dots").fadeIn("fast")) : ($("#eveliidm1 .events3dots").addClass("fa-arrow-up"), $("#eveliidm1 .events3dots").fadeIn("fast"))
    }, function() {
        eveclim1 % 2 == 0 ? ($("#eveliidm1 .events3dots").fadeOut("fast"), $("#eveliidm1 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliidm1 .events3dots").fadeOut("fast"), $("#eveliidm1 .events3dots").removeClass("fa-arrow-up"))
    })
});

var evecli0 = 0;
$(document).ready(function() {
    $("#eveliid0").click(function() {
        evecli0++, evecli0 % 2 == 0 ? ($("#eveliid0").css("background-color", "#ffffff"), $("#eveliid0 .events3dots").removeClass("fa-arrow-up"), $("#eveliid0 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid0").css("background-color", "#eeeeee"), $("#eveliid0 .events3dots").removeClass("fa-arrow-down"), $("#eveliid0 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid0").hover(function() {
        evecli0 % 2 == 0 ? ($("#eveliid0 .events3dots").addClass("fa-arrow-down"), $("#eveliid0 .events3dots").fadeIn("fast")) : ($("#eveliid0 .events3dots").addClass("fa-arrow-up"), $("#eveliid0 .events3dots").fadeIn("fast"))
    }, function() {
        evecli0 % 2 == 0 ? ($("#eveliid0 .events3dots").fadeOut("fast"), $("#eveliid0 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid0 .events3dots").fadeOut("fast"), $("#eveliid0 .events3dots").removeClass("fa-arrow-up"))
    })
});
var evecli1 = 0;
$(document).ready(function() {
    $("#eveliid1").click(function() {
        evecli1++, evecli1 % 2 == 0 ? ($("#eveliid1").css("background-color", "#ffffff"), $("#eveliid1 .events3dots").removeClass("fa-arrow-up"), $("#eveliid1 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid1").css("background-color", "#eeeeee"), $("#eveliid1 .events3dots").removeClass("fa-arrow-down"), $("#eveliid1 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid1").hover(function() {
        evecli1 % 2 == 0 ? ($("#eveliid1 .events3dots").addClass("fa-arrow-down"), $("#eveliid1 .events3dots").fadeIn("fast")) : ($("#eveliid1 .events3dots").addClass("fa-arrow-up"), $("#eveliid1 .events3dots").fadeIn("fast"))
    }, function() {
        evecli1 % 2 == 0 ? ($("#eveliid1 .events3dots").fadeOut("fast"), $("#eveliid1 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid1 .events3dots").fadeOut("fast"), $("#eveliid1 .events3dots").removeClass("fa-arrow-up"))
    })
});
var evecli2 = 0;
$(document).ready(function() {
    $("#eveliid2").click(function() {
        evecli2++, evecli2 % 2 == 0 ? ($("#eveliid2").css("background-color", "#ffffff"), $("#eveliid2 .events3dots").removeClass("fa-arrow-up"), $("#eveliid2 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid2").css("background-color", "#eeeeee"), $("#eveliid2 .events3dots").removeClass("fa-arrow-down"), $("#eveliid2 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid2").hover(function() {
        evecli2 % 2 == 0 ? ($("#eveliid2 .events3dots").addClass("fa-arrow-down"), $("#eveliid2 .events3dots").fadeIn("fast")) : ($("#eveliid2 .events3dots").addClass("fa-arrow-up"), $("#eveliid2 .events3dots").fadeIn("fast"))
    }, function() {
        evecli2 % 2 == 0 ? ($("#eveliid2 .events3dots").fadeOut("fast"), $("#eveliid2 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid2 .events3dots").fadeOut("fast"), $("#eveliid2 .events3dots").removeClass("fa-arrow-up"))
    })
});
var evecli3 = 0;
$(document).ready(function() {
    $("#eveliid3").click(function() {
        evecli3++, evecli3 % 2 == 0 ? ($("#eveliid3").css("background-color", "#ffffff"), $("#eveliid3 .events3dots").removeClass("fa-arrow-up"), $("#eveliid3 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid3").css("background-color", "#eeeeee"), $("#eveliid3 .events3dots").removeClass("fa-arrow-down"), $("#eveliid3 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid3").hover(function() {
        evecli3 % 2 == 0 ? ($("#eveliid3 .events3dots").addClass("fa-arrow-down"), $("#eveliid3 .events3dots").fadeIn("fast")) : ($("#eveliid3 .events3dots").addClass("fa-arrow-up"), $("#eveliid3 .events3dots").fadeIn("fast"))
    }, function() {
        evecli3 % 2 == 0 ? ($("#eveliid3 .events3dots").fadeOut("fast"), $("#eveliid3 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid3 .events3dots").fadeOut("fast"), $("#eveliid3 .events3dots").removeClass("fa-arrow-up"))
    })
});
var evecli4 = 0;
$(document).ready(function() {
    $("#eveliid4").click(function() {
        evecli4++, evecli4 % 2 == 0 ? ($("#eveliid4").css("background-color", "#ffffff"), $("#eveliid4 .events3dots").removeClass("fa-arrow-up"), $("#eveliid4 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid4").css("background-color", "#eeeeee"), $("#eveliid4 .events3dots").removeClass("fa-arrow-down"), $("#eveliid4 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid4").hover(function() {
        evecli4 % 2 == 0 ? ($("#eveliid4 .events3dots").addClass("fa-arrow-down"), $("#eveliid4 .events3dots").fadeIn("fast")) : ($("#eveliid4 .events3dots").addClass("fa-arrow-up"), $("#eveliid4 .events3dots").fadeIn("fast"))
    }, function() {
        evecli4 % 2 == 0 ? ($("#eveliid4 .events3dots").fadeOut("fast"), $("#eveliid4 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid4 .events3dots").fadeOut("fast"), $("#eveliid4 .events3dots").removeClass("fa-arrow-up"))
    })
});
var evecli5 = 0;
$(document).ready(function() {
    $("#eveliid5").click(function() {
        evecli5++, evecli5 % 2 == 0 ? ($("#eveliid5").css("background-color", "#ffffff"), $("#eveliid5 .events3dots").removeClass("fa-arrow-up"), $("#eveliid5 .events3dots").addClass("fa-arrow-down")) : ($("#eveliid5").css("background-color", "#eeeeee"), $("#eveliid5 .events3dots").removeClass("fa-arrow-down"), $("#eveliid5 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#eveliid5").hover(function() {
        evecli5 % 2 == 0 ? ($("#eveliid5 .events3dots").addClass("fa-arrow-down"), $("#eveliid5 .events3dots").fadeIn("fast")) : ($("#eveliid5 .events3dots").addClass("fa-arrow-up"), $("#eveliid5 .events3dots").fadeIn("fast"))
    }, function() {
        evecli5 % 2 == 0 ? ($("#eveliid5 .events3dots").fadeOut("fast"), $("#eveliid5 .events3dots").removeClass("fa-arrow-down")) : ($("#eveliid5 .events3dots").fadeOut("fast"), $("#eveliid5 .events3dots").removeClass("fa-arrow-up"))
    })
});
var achicli1 = 0;
$(document).ready(function() {
    $("#achili1").click(function() {
        achicli1++, achicli1 % 2 == 0 ? ($("#achili1").css("background-color", "#ffffff"), $("#achili1 .events3dots").removeClass("fa-arrow-up"), $("#achili1 .events3dots").addClass("fa-arrow-down")) : ($("#achili1").css("background-color", "#eeeeee"), $("#achili1 .events3dots").removeClass("fa-arrow-down"), $("#achili1 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#achili1").hover(function() {
        achicli1 % 2 == 0 ? ($("#achili1 .events3dots").addClass("fa-arrow-down"), $("#achili1 .events3dots").fadeIn("fast")) : ($("#achili1 .events3dots").addClass("fa-arrow-up"), $("#achili1 .events3dots").fadeIn("fast"))
    }, function() {
        achicli1 % 2 == 0 ? ($("#achili1 .events3dots").fadeOut("fast"), $("#achili1 .events3dots").removeClass("fa-arrow-down")) : ($("#achili1 .events3dots").fadeOut("fast"), $("#achili1 .events3dots").removeClass("fa-arrow-up"))
    })
});
var achicli2 = 0;
$(document).ready(function() {
    $("#achili2").click(function() {
        achicli2++, achicli2 % 2 == 0 ? ($("#achili2").css("background-color", "#ffffff"), $("#achili2 .events3dots").removeClass("fa-arrow-up"), $("#achili2 .events3dots").addClass("fa-arrow-down")) : ($("#achili2").css("background-color", "#eeeeee"), $("#achili2 .events3dots").removeClass("fa-arrow-down"), $("#achili2 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#achili2").hover(function() {
        achicli2 % 2 == 0 ? ($("#achili2 .events3dots").addClass("fa-arrow-down"), $("#achili2 .events3dots").fadeIn("fast")) : ($("#achili2 .events3dots").addClass("fa-arrow-up"), $("#achili2 .events3dots").fadeIn("fast"))
    }, function() {
        achicli2 % 2 == 0 ? ($("#achili2 .events3dots").fadeOut("fast"), $("#achili2 .events3dots").removeClass("fa-arrow-down")) : ($("#achili2 .events3dots").fadeOut("fast"), $("#achili2 .events3dots").removeClass("fa-arrow-up"))
    })
});
var achicli3 = 0;
$(document).ready(function() {
    $("#achili3").click(function() {
        achicli3++, achicli3 % 2 == 0 ? ($("#achili3").css("background-color", "#ffffff"), $("#achili3 .events3dots").removeClass("fa-arrow-up"), $("#achili3 .events3dots").addClass("fa-arrow-down")) : ($("#achili3").css("background-color", "#eeeeee"), $("#achili3 .events3dots").removeClass("fa-arrow-down"), $("#achili3 .events3dots").addClass("fa-arrow-up"))
    })
}), $(document).ready(function() {
    $("#achili3").hover(function() {
        achicli3 % 2 == 0 ? ($("#achili3 .events3dots").addClass("fa-arrow-down"), $("#achili3 .events3dots").fadeIn("fast")) : ($("#achili3 .events3dots").addClass("fa-arrow-up"), $("#achili3 .events3dots").fadeIn("fast"))
    }, function() {
        achicli3 % 2 == 0 ? ($("#achili3 .events3dots").fadeOut("fast"), $("#achili3 .events3dots").removeClass("fa-arrow-down")) : ($("#achili3 .events3dots").fadeOut("fast"), $("#achili3 .events3dots").removeClass("fa-arrow-up"))
    })
}), $("#nav nav a").on("click", function(e) {
    $(".navbara").removeClass("aactive"), $(this).addClass("aactive")
}), $(window).on("scroll", function() {
    $(".target").each(function() {
        if ($(window).scrollTop() >= $(this).position().top - 120) {
            var e = $(this).attr("id");
            $("#nav nav a").removeClass("aactive"), $("#nav nav a[href=#" + e + "]").addClass("aactive")
        }
    })
});